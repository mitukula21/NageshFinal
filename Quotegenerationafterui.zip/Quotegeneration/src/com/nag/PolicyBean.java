package com.nag;

public class PolicyBean 
{
	private int pol_ques_id;
	private String bus_seg_id;
	private String POL_QUES_DESC;                                     
	private String POL_QUES_ANS1;                                      
	private int POL_QUES_ANS1_WEIGHTAGE;                            
	private String POL_QUES_ANS2;                                     
	private int POL_QUES_ANS2_WEIGHTAGE;                            
	private String POL_QUES_ANS3;                                      
	private int POL_QUES_ANS3_WEIGHTAGE;
	public int getPol_ques_id() {
		return pol_ques_id;
	}
	public void setPol_ques_id(int pol_ques_id) {
		this.pol_ques_id = pol_ques_id;
	}
	public String getBus_seg_id() {
		return bus_seg_id;
	}
	public void setBus_seg_id(String bus_seg_id) {
		this.bus_seg_id = bus_seg_id;
	}
	public String getPOL_QUES_DESC() {
		return POL_QUES_DESC;
	}
	public void setPOL_QUES_DESC(String pOL_QUES_DESC) {
		POL_QUES_DESC = pOL_QUES_DESC;
	}
	public String getPOL_QUES_ANS1() {
		return POL_QUES_ANS1;
	}
	public void setPOL_QUES_ANS1(String pOL_QUES_ANS1) {
		POL_QUES_ANS1 = pOL_QUES_ANS1;
	}
	public int getPOL_QUES_ANS1_WEIGHTAGE() {
		return POL_QUES_ANS1_WEIGHTAGE;
	}
	public void setPOL_QUES_ANS1_WEIGHTAGE(int pOL_QUES_ANS1_WEIGHTAGE) {
		POL_QUES_ANS1_WEIGHTAGE = pOL_QUES_ANS1_WEIGHTAGE;
	}
	public String getPOL_QUES_ANS2() {
		return POL_QUES_ANS2;
	}
	public void setPOL_QUES_ANS2(String pOL_QUES_ANS2) {
		POL_QUES_ANS2 = pOL_QUES_ANS2;
	}
	public int getPOL_QUES_ANS2_WEIGHTAGE() {
		return POL_QUES_ANS2_WEIGHTAGE;
	}
	public void setPOL_QUES_ANS2_WEIGHTAGE(int pOL_QUES_ANS2_WEIGHTAGE) {
		POL_QUES_ANS2_WEIGHTAGE = pOL_QUES_ANS2_WEIGHTAGE;
	}
	public String getPOL_QUES_ANS3() {
		return POL_QUES_ANS3;
	}
	public void setPOL_QUES_ANS3(String pOL_QUES_ANS3) {
		POL_QUES_ANS3 = pOL_QUES_ANS3;
	}
	public int getPOL_QUES_ANS3_WEIGHTAGE() {
		return POL_QUES_ANS3_WEIGHTAGE;
	}
	public void setPOL_QUES_ANS3_WEIGHTAGE(int pOL_QUES_ANS3_WEIGHTAGE) {
		POL_QUES_ANS3_WEIGHTAGE = pOL_QUES_ANS3_WEIGHTAGE;
	}
	
	
}
