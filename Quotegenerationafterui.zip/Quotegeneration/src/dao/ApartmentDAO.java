package dao;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
 
import com.nag.ApartmentBean;
 
 
 
public class ApartmentDAO
{
 
 
	  public static int addStudent1(ApartmentBean bean)
	  {
		  Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
 
			  con=AccountDB.getConnection(); 
			 /* String sqk="SELECT questionid.currVAL from dual";
			  pstmt = con.prepareStatement(sqk);
			  pstmt.executeQuery();*/
			  String ins_str = 
				  "insert into apartment values(questionid.nextVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
			  pstmt = con.prepareStatement(ins_str);
			  String q1="Apartment Sqft";
			  String q2="Number of Sprinklers";
			  String q3="Build Year";
			  String q5="Property Damage";
			  String q6="Bodily Injury Limit";
			  String q4="Number of Floors";
			  String q8="Number of FireExits";
			  String q7="Asset Theft Limit";
 
 
 
			  pstmt.setString(1,q1);
			  pstmt.setString(2,bean.getApartmentSqft());
 
			  pstmt.setString(3,q2);
			  pstmt.setString(4,bean.getNumberofSprinklers());
			  pstmt.setString(5,q3);
 
			  pstmt.setString(6,bean.getBuildYear());
			  pstmt.setString(7,q5);
			  pstmt.setString(8,bean.getPropertyDamage());
			  pstmt.setString(9,q7);
			  pstmt.setString(10,bean.getBodilyInjuryLimit());
			  pstmt.setString(11,q8);
			  pstmt.setString(12,bean.getNumberofFloors());
			  pstmt.setString(13,q6);
			  pstmt.setString(14,bean.getNumberofFireExits());
			  pstmt.setString(15,q8);
			  pstmt.setString(16,bean.getAssetTheftLimit());
 
 
			  pstmt.setInt(17,bean.getAccount_number());
 
 
 
			  int updateCount = pstmt.executeUpdate();
 
			  con.close();
 
			  return updateCount;
 
 
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
 
	  }
	}