package services;
import com.nag.ApartmentBean;

import dao.ApartmentDAO;
 
public class ApartmentService 
{
 
 
	public int addStudentService(String apartmentSqft,String numberofSprinklers,String buildYear,String propertyDamage,String bodilyInjuryLimit,String numberofFloors,String numberofFireExits,String assetTheftLimit,int account_number)
	 {
 
 
		ApartmentDAO bookDAO = new  ApartmentDAO();
		ApartmentBean businessBean = new ApartmentBean();
		 //wrap up all the four field values into bean
 
		 businessBean.setApartmentSqft(apartmentSqft);
		 businessBean.setNumberofSprinklers(numberofSprinklers);
		 businessBean.setBuildYear(buildYear);
		 businessBean.setPropertyDamage(propertyDamage);
 
		 businessBean.setBodilyInjuryLimit(bodilyInjuryLimit);
		 businessBean.setNumberofFloors(numberofFloors);
		 businessBean.setNumberofFireExits(numberofFireExits);
		 businessBean.setAssetTheftLimit(assetTheftLimit);
 
		 businessBean.setAccount_number(account_number);
		 int updateResult = 0;
		 try
		 {
			 updateResult = ApartmentDAO.addStudent1(businessBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
}