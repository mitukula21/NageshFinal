package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/Fetch3")
public class Fetch3 extends HttpServlet
{
	private static final long serialVersionUID = 1L;
 
    public Fetch3() {
        super();
        // TODO Auto-generated constructor stub
    }
 
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
 
		String ID = request.getParameter("id");
		int id = Integer.parseInt(ID);
        
		try { 
			Class.forName("oracle.jdbc.OracleDriver");
		
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
			PreparedStatement ps = con.prepareStatement("\r\n" + 
					"select accountcreation.insured_name,accountcreation.insured_street,\r\n" + 
					"accountcreation.insured_city,accountcreation.insured_state,\r\n" + 
					"accountcreation.insured_zip,accountcreation.business_segment,\r\n" + 
					"accountcreation.account_number,apartment.question_id,\r\n" + 
					"apartment.q1,apartment.apartmentsqft,apartment.q2,\r\n" + 
					"apartment.numberofsprinklers,apartment.q3,apartment.buildyear,\r\n" + 
					"apartment.q4,apartment.propertydamage,apartment.q5,\r\n" + 
					"apartment.bodilyinjurylimit,apartment.q6,apartment.numberoffloors,\r\n" + 
					"apartment.q7,apartment.numberoffireexits,apartment.q8,apartment.assettheftlimit from accountcreation \r\n" + 
					"full outer join apartment on accountcreation.account_number=apartment.account_number where apartment.account_number=?");
PreparedStatement ps1 = con.prepareStatement("select sum(APARTMENTSQFT+NUMBEROFSPRINKLERS+BUILDYEAR+PROPERTYDAMAGE+BODILYINJURYLIMIT+NUMBEROFFLOORS+NUMBEROFFIREEXITS+ASSETTHEFTLIMIT) as sum from apartment where account_number=?");
			ps.setInt(1, id);
			ps1.setInt(1, id);
			
 
			ResultSet rs = ps.executeQuery();
 
			while (rs.next()) {
				out.println(
						"InsuredName: " + rs.getString(1) + 
						"</br> insured Street: "+ rs.getString(2) + "</br> Insuredcity: " + rs.getString(3)+
						"</br> Insured state: " + rs.getString(4)+ "</br> insuredZip: " + rs.getInt(5)+ 
						"</br> Businesssegment: " + rs.getString(6)+ "</br> Accountnumber: " + rs.getInt(7)+ 
						" </br>Questionid: " + rs.getInt(8) + 
						"</br> question1: "+ rs.getString(9) + "</br> Answer1: " + rs.getString(10)+
						"</br> question2: " + rs.getString(11)+ "</br> Answer2: " + rs.getString(12)+ 
						"</br> question3: " + rs.getString(13)+ "</br> answer3: " + rs.getString(14)+ 
						"</br> question4: " + rs.getString(15)+ "</br> Answer4: " + rs.getString(16)+ 
						"</br> question5: " + rs.getString(17)+ "</br> Answer5: " + rs.getString(18)+ 
						"</br> question6: " + rs.getString(19)+ "</br> Answer6: " + rs.getString(20)+ 
						"</br> question7: " + rs.getString(21)+ "</br> Answer7: " + rs.getString(22)+
						"</br> question8: " + rs.getString(23)+ "</br> Answer8: " + rs.getString(24));
				
			}
			ResultSet rs1 = ps1.executeQuery();
			 
			while (rs1.next()) 
			{
				out.println("</br>Premium:"+rs1.getInt(1));
			}
			out.println("</br></br><a href='Admin.jsp'>Return to admin</a>");
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			out.close();
		}
		System.out.println("retrieved data");
	
	}
	
	
}