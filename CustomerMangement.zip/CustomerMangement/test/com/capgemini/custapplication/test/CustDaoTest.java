package com.capgemini.custapplication.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.dao.custDaoImpl;
import com.capgemini.custapplication.exception.CustException;
import com.capgemini.custapplication.service.CustServiceImpl;
import com.capgemini.custapplication.service.ICustService;

public class CustDaoTest {

	static custDaoImpl dao;
	static CustBean cust;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new custDaoImpl();
		cust = new CustBean();
	}

	@Test
	public void testAddCustDetails() throws CustException {

		assertNotNull(dao.addCustDetails(cust));

	}


	@Ignore
	@Test
	public void testAddCustDetails1() throws CustException {
		// increment the number next time you test for positive test case
		assertEquals(1001, dao.addCustDetails(cust));
	}

	

	/*@Test
	public void testAddCustDetails2() throws CustException {

		cust.setPname("ShashwathiNew");
		cust.setPno("9876543212");
		cust.setPdesc("whitefieldVydehi");
		cust.setAge(120);
		assertEquals(1001, dao.addCustDetails(cust));
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);

	}
*/
	
	@Test
	public void testViewAll() throws CustException {
		assertNotNull(dao.retriveAllDetails());
	}



	@Test
	public void testById() throws CustException {
		assertNotNull(dao.viewCustDetails("1001"));
	}

//	@Ignore
	/*@Test
	public void testById1() throws CustException {
		assertEquals("TestName", dao.viewCustDetails("1001").getPname());
	}
*/
}
