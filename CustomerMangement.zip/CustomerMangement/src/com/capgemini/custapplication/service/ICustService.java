package com.capgemini.custapplication.service;

import java.util.List;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;

public interface ICustService {

	public String addCustDetails(CustBean cust) throws CustException;
	public CustBean viewCustDetails(String custId) throws CustException;
	public List<CustBean> retriveAll()throws CustException;
}
