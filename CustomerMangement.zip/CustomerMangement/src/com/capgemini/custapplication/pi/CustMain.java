package com.capgemini.custapplication.pi;


import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;
import com.capgemini.custapplication.service.CustServiceImpl;
import com.capgemini.custapplication.service.ICustService;

public class CustMain {

	static Scanner sc = new Scanner(System.in);
	static ICustService custService = null;
	static CustServiceImpl custServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		CustBean custBean = null;

		String custid = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("CUSTOMER MANAGEMENT ");
			System.out.println("_______________________________\n");

			System.out.println("1.Insert customer details ");
			System.out.println("2.Update customer");
			System.out.println("3.Listing customer");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (custBean == null) {
						custBean = populateCustBean();
						// System.out.println(donorBean);
					}

					try {
						custService = new CustServiceImpl();
						custid = custService.addCustDetails(custBean);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer  ID Is: " + custid);

					} catch (CustException custException) {
						logger.error("exception occured", custException);
						System.err.println("ERROR : "+ custException.getMessage());
					} finally {
						custid = null;
						custService = null;
						custBean = null;
					}

					break;

				case 2:

					custServiceImpl = new CustServiceImpl();

					System.out.println("Enter numeric customer id:");
					custid = sc.next();

					while (true) {
						if (custServiceImpl.validateCustId(custid)) {
							break;
						} else {
							System.err.println("Please enter numeric customer id only, try again");
							custid = sc.next();
						}
					}

					custBean = getCustDetails(custid);

					if (custBean != null) {
						System.out.println("Name             :"
								+ custBean.getFullname());
						/*System.out.println("Description          :"
								+ custBean.getPdesc());
						System.out.println("Phone Number     :"
								+ custBean.getPno());
						System.out.println(" Date       :"
								+ custBean.getPdate());
						System.out.println("age is  :"
								+ custBean.getAge());*/
					} 
					else {
						System.err
								.println("There are no  details associated with customer id "
										+ custid);
					}

					break;

				case 3:

					custService = new CustServiceImpl();
					try {
						List<CustBean> custList = new ArrayList<CustBean>();
						custList = custService.retriveAll();

						if (custList != null) {
							Iterator<CustBean> i = custList.iterator();
							while (i.hasNext())
							{
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("correct details");
						}

					}

					catch (CustException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;

				case 4:

					System.out.print("Exit Customer Management");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given custId in
	 * parameter
	 */
	private static CustBean getCustDetails(String custId) {
		CustBean custBean = null;
		custService = new CustServiceImpl();

		try {
			custBean = custService.viewCustDetails(custId);
		} catch (CustException custException) {
			logger.error("exception occured ", custException);
			System.out.println("ERROR : " + custException.getMessage());
		}

		custService = null;
		return custBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private  static CustBean populateCustBean() {

		// Reading and setting the values for the donorBean
		
		CustBean custBean = new CustBean();

		System.out.println("\n Enter Details");

		System.out.println("Enter customer email: ");
		custBean.setEmail(sc.next());
		
		System.out.println("Enter customer name: ");
		custBean.setFullname(sc.next());
		
		System.out.println("Enter customer password: ");
		custBean.setPassword(sc.next());

		System.out.println("Enter customer confirm password:");
		custBean.setConfirmpassword(sc.next());

		System.out.println("Enter age : ");

		try {
			custBean.setZipcode(sc.nextInt());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err.println("Please enter a numeric value for age amount, try again");
			}

		custServiceImpl = new CustServiceImpl();

		try {
			custServiceImpl.validatecust(custBean);
			return custBean;
		}
		catch (CustException custException) {
			logger.error("exception occured", custException);
			System.err.println("Invalid data:");
			System.err.println(custException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
