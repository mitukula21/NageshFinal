package com.capgemini.custapplication.exception;

public class CustException  extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public CustException(String message) 
	{
		
		super(message);
	}
}
