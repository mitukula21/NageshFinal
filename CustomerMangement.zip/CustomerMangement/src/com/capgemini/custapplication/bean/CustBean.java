package com.capgemini.custapplication.bean;

import java.util.Date;

public class CustBean 
{
	private int custid;
	private String email;
	private String fullname;
	private String password;
	private String confirmpassword;
	private long phonenumber;
	private String address;
	private String city;
	private long zipcode;
	private String country;
	private Date regestrationdate;
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setZipcode(long zipcode) {
		this.zipcode = zipcode;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setRegestrationdate(Date regestrationdate) {
		this.regestrationdate = regestrationdate;
	}
	public int getCustid() {
		return custid;
	}
	public String getEmail() {
		return email;
	}
	public String getFullname() {
		return fullname;
	}
	public String getPassword() {
		return password;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public long getPhonenumber() {
		return phonenumber;
	}
	public String getAddress() {
		return address;
	}
	public String getCity() {
		return city;
	}
	public long getZipcode() {
		return zipcode;
	}
	public String getCountry() {
		return country;
	}
	public Date getRegestrationdate() {
		return regestrationdate;
	}
	@Override
	public String toString() {
		return "CustBean [custid=" + custid + ", email=" + email + ", fullname=" + fullname + ", password=" + password
				+ ", confirmpassword=" + confirmpassword + ", phonenumber=" + phonenumber + ", address=" + address
				+ ", city=" + city + ", zipcode=" + zipcode + ", country=" + country + ", regestrationdate="
				+ regestrationdate + "]";
	}
	
	
	
}
