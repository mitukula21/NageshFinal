package services;

import com.nag.GeneralBean;

import dao.GeneralDAO;
 
 
 
 
public class GeneralService 
{
 
 
	public int addStudentService(String businessType,String assetValue,String inflammableObjects,String popertySize,String propertyDamage,String bodilyInjury,String assetTheftLimit,String liablityCoverage,int account_number)
	 {
 
 
		GeneralDAO bookDAO = new  GeneralDAO();
		GeneralBean businessBean = new GeneralBean();
		 //wrap up all the four field values into bean
 
		 businessBean.setBusinessType(businessType);
		 businessBean.setAssetValue(assetValue);
		 businessBean.setInflammableObjects(inflammableObjects);
		 businessBean.setPopertySize(popertySize);
 
		 businessBean.setPropertyDamage(propertyDamage);
		 businessBean.setBodilyInjury(bodilyInjury);
		 businessBean.setAssetTheftLimit(assetTheftLimit);
		 businessBean.setLiablityCoverage(liablityCoverage);
 
		 businessBean.setAccount_number(account_number);
		 int updateResult = 0;
		 try
		 {
			 updateResult = GeneralDAO.addStudent1(businessBean);
			 return updateResult;
		 }
		 catch(Exception ex)
		 {
			 System.out.println(ex.toString());
			 return 0;
		 }
	 }
}
