package com.nag;
 
public class ApartmentBean {
	private String apartmentSqft;
	private String numberofSprinklers;
	private String buildYear;
	private String propertyDamage;
	private String bodilyInjuryLimit;
	private String numberofFloors;
	private String numberofFireExits;
	private String assetTheftLimit;
 
	private int account_number;
 
	public String getApartmentSqft() {
		return apartmentSqft;
	}
 
	public void setApartmentSqft(String apartmentSqft) {
		this.apartmentSqft = apartmentSqft;
	}
 
	public String getNumberofSprinklers() {
		return numberofSprinklers;
	}
 
	public void setNumberofSprinklers(String numberofSprinklers) {
		this.numberofSprinklers = numberofSprinklers;
	}
 
	public String getBuildYear() {
		return buildYear;
	}
 
	public void setBuildYear(String buildYear) {
		this.buildYear = buildYear;
	}
 
	public String getPropertyDamage() {
		return propertyDamage;
	}
 
	public void setPropertyDamage(String propertyDamage) {
		this.propertyDamage = propertyDamage;
	}
 
	public String getBodilyInjuryLimit() {
		return bodilyInjuryLimit;
	}
 
	public void setBodilyInjuryLimit(String bodilyInjuryLimit) {
		this.bodilyInjuryLimit = bodilyInjuryLimit;
	}
 
	public String getNumberofFloors() {
		return numberofFloors;
	}
 
	public void setNumberofFloors(String numberofFloors) {
		this.numberofFloors = numberofFloors;
	}
 
	public String getNumberofFireExits() {
		return numberofFireExits;
	}
 
	public void setNumberofFireExits(String numberofFireExits) {
		this.numberofFireExits = numberofFireExits;
	}
 
	public String getAssetTheftLimit() {
		return assetTheftLimit;
	}
 
	public void setAssetTheftLimit(String assetTheftLimit) {
		this.assetTheftLimit = assetTheftLimit;
	}
 
	public int getAccount_number() {
		return account_number;
	}
 
	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}
 
 
 
}